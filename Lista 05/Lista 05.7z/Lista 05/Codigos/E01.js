/*
* 1. Crie um objeto representando um livro, com campos para título, autor e número de páginas. Emita diretamente como saída no console a variável que representa o objeto.
*/

let livro = {
    titulo : "Briga de cachorro grande",
    Autor : "Fred Vogelsten",
    Qntpaginas : 520
}

console.log(livro);