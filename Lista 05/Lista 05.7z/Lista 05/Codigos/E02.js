// 2. Modifique a questão anterior para emitir uma linha de saída separada para cada uma das três propriedades do objeto.


let livro = {
    titulo : "Briga de cachorro grande",
    Autor : "Fred Vogelsten",
    Qntpaginas : 520
}

console.log("Nome do livro: " + livro.titulo);
console.log("Nome do autor: " + livro.Autor);
console.log("Quantidade de páginas: " + livro.Qntpaginas);